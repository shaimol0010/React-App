
//reducer for getting the status of the data from api

const initialState: boolean = false;
export default function loadReducer(state = initialState, action: any) {
  switch (action.type) {
    case "LOADING_STATUS":
      return action.payload;
    default:
      return state;
  }
}
