//reducer for all the employee related actions
const initialState:any[]=[];
export default function userReducer(state = initialState,action: any) {
    switch (action.type) {
        case "ADD_EMPLOYEE":
            return [ ...state, action.payload ]

        case "DELETE_EMPLOYEE":
            console.log("jesus delete",action.payload)
            const updatedEmployee: any= state.filter(
                (user) => user.id !== action.payload.id
              );
              console.log("updatedEmployee",updatedEmployee)
            return  updatedEmployee 


        case "EDIT_EMPLOYEE":
            console.log("jesus edit",action.payload)
            const editedEmployee: any= state.map(
                (user) =>{
                    if(user.id === (action.payload.id)){return action.payload}else{return user}
                }
                  );
                console.log("updatedEmployee",editedEmployee)
            return  editedEmployee

            
        case "FETCH_EMPLOYEE":
                 return action.payload 
        default:
            return state;
    }
}