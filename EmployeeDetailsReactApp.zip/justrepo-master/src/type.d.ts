interface User {
    userId: number;
    id: number;
    title: string;
    completed: boolean;
}

type UserState = {
    users: User[]
  }
  
  type UserAction = {
    type: string
    users: User
  }
  
  type DispatchType = (args: UserAction) => UserAction