import { Form, Input, Button } from 'antd';
import './tableComponent.css';
import { useHistory } from "react-router-dom";
import { useDispatch,useSelector } from 'react-redux';

const layout = {
    labelCol: {
        span: 4,
    },
    wrapperCol: {
        span: 16,
    },
};

interface User {
    userId: number;
    id: number;
    title: string;
    completed: boolean;
}
// interface functionProps {
//     parentCallBack(user: User): void;
// }
const AddEmployee: React.FC = () => {
    const dispatch=useDispatch();
    const history = useHistory();
    const employees = useSelector((store: any) => store.user);

    const onFinish = (values: User) => {
        console.log(values);
        // parentCallBack(values);
        alert("Employee Details added successfully");
        dispatch({type:"ADD_EMPLOYEE", payload : values});
        console.log("After Addition",employees)
    };
    const backToHome = (e: any) => {

        e.preventDefault();
        history.push("/");
    }

    return (
        <Form className="addEmployeeDiv" {...layout} name="nest-messages" onFinish={onFinish}>
            <h2>Add an Employee Detail</h2>
            <Form.Item
                name={['userId']}
                label="USER ID"
            >
                <Input />
            </Form.Item>

            <Form.Item
                name={['id']}
                label="ID"
            >
                <Input />
            </Form.Item>


            <Form.Item
                name={['title']}
                label="TITLE"
                rules={[
                    {
                        type: 'string',
                    },
                ]}
            >
                <Input />
            </Form.Item>

            <Form.Item
                name={['completed']}
                label="COMPLETED"
                rules={[
                    {
                        type: 'string',
                    },
                ]}
            >
                <Input />
            </Form.Item>

            <Form.Item wrapperCol={{ ...layout.wrapperCol, offset: 4 }}>
                <Button className="buttonSave" type="primary" htmlType="submit">
                    SAVE
                </Button>
                <Button onClick={backToHome} type="primary">
                    BACK
                </Button>
            </Form.Item>
        </Form>

    );
}

export default AddEmployee;