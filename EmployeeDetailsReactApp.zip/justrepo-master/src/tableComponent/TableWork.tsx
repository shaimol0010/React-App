import { useState, useEffect } from "react";
import { EditOutlined, DeleteOutlined } from "@ant-design/icons";
import { Table, Modal, Input, Button, Spin } from "antd";
import { useHistory } from "react-router-dom";
import './tableComponent.css';
import AddEmployee from "./AddEmployee";
import { useSelector, useDispatch } from 'react-redux';
import store from "../store";

function TableWork() {

    // initialize hooks
    const [isEditing, setIsEditing] = useState(false);
    const [editingEmployee, setEditingEmployee] = useState<User | null>(null);
    const [users] = useState<User[]>([]);
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const dispatch = useDispatch();
    const employees = useSelector((store: any) => store.user);
    const history = useHistory();
    const status = useSelector((store: any) => store.status);
    const [loading, setLoading] = useState(!status);

    useEffect(() => { }, [employees])

    //navigate to graph page
    const showChart = (e: any) => {
        e.preventDefault();
        history.push("/graphsample");
    }

    const addEmployee = (e: any) => {

        e.preventDefault();
        history.push("/addEmployee");
    }

    //User interface
    interface User {
        userId: number;
        id: number;
        title: string;
        completed: boolean;
    }

    //columns for table
    const columns = [
        {
            title: 'ID',
            dataIndex: 'id',
            key: 'id',
            sorter: (record1: User, record2: User) => {
                return record1.id > record2.id ? 1 : -1
            },
        },
        {
            title: 'USERID',
            dataIndex: 'userId',
            key: 'userId',
        },
        {
            title: 'TITLE',
            dataIndex: 'title',
            key: 'title',
        },

        {
            key: 'completed',
            title: 'COMPLETED',
            dataIndex: 'completed',
            render: (status: any) => {
                return (status ? "Yes" : "No")
            },
            filters: [
                {
                    text: "Yes",
                    value: true,
                },
                {
                    text: "No",
                    value: false,
                }
            ],
            onFilter: (value: any, record: User) => record.completed === value,
        },
        {
            key: "actions",
            title: "Actions",
            render: (record: User) => {
                return (
                    <>
                        <EditOutlined
                            onClick={() => {
                                onEditEmployee(record);
                            }}
                        />
                        <DeleteOutlined
                            onClick={() => {
                                onDeleteEmployee(record);
                            }}
                            style={{ color: "red", marginLeft: 12 }}
                        />
                    </>
                );
            },
        },
    ];

    //Deletes an Employee
    const onDeleteEmployee = (record: User) => {
        Modal.confirm({
            title: "Are you sure, you want to delete this Employee record?",
            okText: "Yes",
            okType: "danger",
            onOk: () => {
                dispatch({ type: "DELETE_EMPLOYEE", payload: record })
            },
        });
    };


    //Edits an employee
    const onEditEmployee = (record: User) => {
        setIsEditing(true);
        setEditingEmployee({ ...record });
    };

    const resetEditing = () => {
        setIsEditing(false);
        setEditingEmployee(null);
    };

    // //Add  Employee Callback function
    // const handleCallBack = (childData: User): void => {
    //     //console.log("Data Employee", childData);
    //     const newUser = [...users, childData];
    //     //console.log("After Addition", newUser);
    //     dispatch({ type: "ADD_EMPLOYEE", payload: childData })
    // }

    //Get Api call
    useEffect(() => {
        if (!status) {
            const axios = require("axios");
            const options = {
                method: "GET",
                url: "https://jsonplaceholder.typicode.com/todos",
            };

            axios
                .request(options)
                .then(function (response: { data: any }) {

                    //console.log("setting data work", response.data);
                    dispatch({ type: "FETCH_EMPLOYEE", payload: response.data });
                    dispatch({ type: "LOADING_STATUS", payload: true });
                    setLoading(false);
                })
                .catch(function (error: any) {
                    console.error(error);
                });
        }

    }, []);

    return (
        <div className="App">

            {/* <AddEmployee parentCallBack={handleCallBack} /> */}
            <Button className="buttonAdd" onClick={addEmployee} type="primary" htmlType="submit">
             ADD EMPLOYEE
                </Button>

            <Button onClick={showChart} type="primary" htmlType="submit">
                SHOW CHART FORMAT
            </Button>

            <h2>Employee Details In Tabular Form</h2>
            <div>

                <Table className="employeeTab"
                    dataSource={employees}
                    columns={columns}
                    pagination={{
                        current: page,
                        pageSize: pageSize,
                        total: users.length,
                        onChange: (page, pageSize) => {
                            setPage(page);
                            setPageSize(pageSize)
                        }
                    }}
                    loading={{ spinning: loading, indicator: <div><Spin size="large" /></div> }}
                />

            </div>
            {/* Employee editing modal */}
            <Modal
                title="Edit Employee"
                visible={isEditing}
                okText="Save"
                onCancel={() => {
                    resetEditing();
                }}
                onOk={() => {
                    dispatch({ type: "EDIT_EMPLOYEE", payload: editingEmployee })
                    resetEditing();
                }}
            >
                <Input
                    value={editingEmployee?.userId}
                    onChange={(e) => {
                        setEditingEmployee((pre: any) => {
                            return { ...pre, userId: e.target.value };
                        });
                    }}
                />
                <Input
                    value={editingEmployee?.title}
                    onChange={(e) => {
                        setEditingEmployee((pre: any) => {
                            return { ...pre, title: e.target.value };
                        });
                    }}
                />
            </Modal>
        </div>
    );
}

export default TableWork;
