import { LineChart, Line, CartesianGrid, XAxis, YAxis } from "recharts";
import { useSelector } from 'react-redux';
import { Button } from 'antd';
import { useHistory } from "react-router-dom";
import './tableComponent.css';


function ChartWork() {
    const history = useHistory();
    //hardcoded data for chart
    const data = [
        {
            name: 'Home Page',
            uv: 600,
            pv: 2400,
            amt: 2400
        },
        {
            name: 'Login Page',
            uv: 500,
            pv: 2400,
            amt: 2400
        },
        {
            name: 'Registration Page',
            uv: 200,
            pv: 2400,
            amt: 2400
        },
        {
            name: 'Contact Page',
            uv: 300,
            pv: 2400,
            amt: 2400
        },
    ];
    const backToHome = (e: any) => {

        e.preventDefault();
        history.push("/");
    }
    return (
        <div className="App">
            <div className="chartDiv">
                <h3>User Visit Per Page</h3>
                <LineChart width={600} height={300} data={data}>
                    <Line type="monotone" dataKey="uv" stroke="black" />
                    <CartesianGrid stroke="#ccc" />
                    <XAxis dataKey="name" />
                    <YAxis />
                </LineChart>
            </div>
            <Button className="backButton" onClick={backToHome} type="primary">
                BACK
            </Button>
        </div>
    );
}

export default ChartWork;
