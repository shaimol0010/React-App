import './App.css';
import TableWork from './tableComponent/TableWork';
import ChartWork from './tableComponent/ChartWork';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import AddEmployee from './tableComponent/AddEmployee';


function App() {
  return (
    <Router>
      <div className="App">
        <Switch>
          <Route path="/graphsample">
            <h1>Track On User Visits </h1>
            <ChartWork />
          </Route>
          <Route path="/addEmployee">
            <AddEmployee />
          </Route>
          <Route path="/">
            <h1>EMPLOYEE DETAILS</h1>
            <TableWork />
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

export default App;
