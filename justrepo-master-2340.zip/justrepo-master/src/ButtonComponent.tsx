/* Write a button component */ 

import { Button } from "antd";
import React from 'react'; 

const ButtonComponent = (props: any) => { 
  
  return ( 
    <Button>{props.text} CLick</Button>
    
  ); 
  
} 

export {ButtonComponent};