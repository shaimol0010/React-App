const initialState:any[]=[];
export default function userReducer(state = initialState,action: any) {
    switch (action.type) {
        case "ADD_EMPLOYEE":
            return [ ...state, action.payload ]
        default:
            return state;
    }
}