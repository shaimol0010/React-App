import { useState, useEffect } from "react";
import { EditOutlined, DeleteOutlined } from "@ant-design/icons";
import { Table, Modal, Input, Button } from "antd";
import { LineChart, Line, CartesianGrid, XAxis, YAxis } from "recharts";
import { PieChart, Pie, Sector, Cell, ResponsiveContainer } from "recharts";
import './tableComponent.css';
import AddEmployee from "./AddEmployee";
import ChartWork from './ChartWork';
import { descending } from "d3";
import { useSelector, useDispatch } from 'react-redux';
import { Provider } from 'react-redux'

function TableWork() {
    // initialize hooks
    const [isEditing, setIsEditing] = useState(false);
    const [editingEmployee, setEditingEmployee] = useState<User | null>(null);
    const [users, setUsers] = useState<User[]>([]);
    const [page, setPage] = useState(1)
    const [pageSize, setPageSize] = useState(10)
    const [error, setError] = useState({});
    const dispatch=useDispatch();
    const employees=useSelector((store: any)=>store.user);//these hoooks used for subcribes and updates data from store

    useEffect(()=>{console.log("UseEffect",employees)},[employees])

    //interface
    interface User {
        userId: number;
        id: number;
        title: string;
        completed: boolean;
    }
    const data = [
        {
            name: 'Page A',
            uv: 400,
            pv: 2400,
            amt: 2400
        },
        {
            name: 'Page B',
            uv: 300,
            pv: 2400,
            amt: 2400
        },
        {
            name: 'Page C',
            uv: 200,
            pv: 2400,
            amt: 2400
        },
        {
            name: 'Page D',
            uv: 100,
            pv: 2400,
            amt: 2400
        },
    ];
    //columns for table
    const columns = [
        {
            title: 'ID',
            dataIndex: 'id',
            key: 'id',
            sorter: (record1: User, record2: User) => { return record1.id > record2.id ? 1 : -1 },
            // sortDirections:['descend'],
        },
        {
            title: 'USERID',
            dataIndex: 'userId',
            key: 'userId',
        },
        {
            title: 'TITLE',
            dataIndex: 'title',
            key: 'title',
        },

        {
            key: 'completed',
            title: 'COMPLETED',
            dataIndex: 'completed',
            render: (status: any) => {
                return (status ? "Yes" : "No")
            },
            filters: [
                {
                    text: "Yes",
                    value: true,
                },
                {
                    text: "No",
                    value: false,
                }
            ],
            onFilter: (value: any, record: User) => record.completed === value,
        },
        {
            key: "actions",
            title: "Actions",
            render: (record: User) => {
                return (
                    <>
                        <EditOutlined
                            onClick={() => {
                                onEditEmployee(record);
                            }}
                        />
                        <DeleteOutlined
                            onClick={() => {
                                onDeleteEmployee(record);
                            }}
                            style={{ color: "red", marginLeft: 12 }}
                        />
                    </>
                );
            },
        },
    ];

    //Delete function for delete a record
    const onDeleteEmployee = (record: User) => {
        Modal.confirm({
            title: "Are you sure, you want to delete this Employee record?",
            okText: "Yes",
            okType: "danger",
            onOk: () => {
                setUsers((pre: any) => {
                    return pre.filter((user: User) => user.id !== record.id);
                });
            },
        });
    };


    //Edit function for Edit a record
    const onEditEmployee = (record: User) => {
        setIsEditing(true);
        setEditingEmployee({ ...record });
    };
    const resetEditing = () => {
        setIsEditing(false);
        setEditingEmployee(null);
    };
//Add  Employee Callback function

    const handleCallBack = (childData: User): void => {

        console.log("Data Employee", childData);
        const newUser = [...users, childData];
        setUsers(newUser);
        console.log("After Addition", newUser);
        dispatch({type:"ADD_EMPLOYEE",payload:childData})

        //const storeUser = useSelector(childData);


    }

    //Get Api call function using useEffect hook
    useEffect(() => {
        const axios = require("axios");
        const options = {
            method: "GET",
            url: "https://jsonplaceholder.typicode.com/todos",
        };

        axios
            .request(options)
            .then(function (response: { data: any }) {
                console.log("setting data work", response.data);

                setUsers(response.data);
            })
            .catch(function (error: any) {
                console.error(error);
            });
    }, []);
    return (
        <div className="App">
            {/* <ChartWork/> */}

            <AddEmployee parentCallBack={handleCallBack} />

            {/* <LineChart width={500} height={300} data={users}>
                <XAxis dataKey="id" />
                <YAxis dataKey="completed" />
                <CartesianGrid stroke="#eee" strokeDasharray="5 5" />
                <Line type="monotone" dataKey="uv" stroke="#8884d8" />
                <Line type="monotone" dataKey="pv" stroke="#82ca9d" />
            </LineChart> */}
            <div className="chartDiv">
                <h3>Employee Details LineChart</h3>
            <LineChart className="chart" width={600} height={300} data={users}>
                <Line type="monotone" dataKey="userId" stroke="black" />
                <CartesianGrid stroke="#ccc" />
                <XAxis dataKey="id" />
                <YAxis dataKey="userId" />
            </LineChart>
            <h3>User Visit LineChart</h3>
            <LineChart width={600} height={300} data={data}>
                <Line type="monotone" dataKey="uv" stroke="black" />
                <CartesianGrid stroke="#ccc" />
                <XAxis dataKey="name" />
                <YAxis />
            </LineChart>
            </div>
            <h2>Employee Details in tabular format</h2>
            {/* <ResponsiveContainer width="100%" height="100%">
                <PieChart width={400} height={400}>
                    <Pie data={users} dataKey="id" cx="50%" cy="50%" outerRadius={60} fill="#8884d8" /> 
                    <Pie data={users} dataKey="status" cx="50%" cy="50%" innerRadius={70} outerRadius={90} fill="#82ca9d" label />
                </PieChart>
            </ResponsiveContainer> */}


            <Table className="employeeTab"
                dataSource={users}
                columns={columns}
                pagination={{
                    current: page,
                    pageSize: pageSize,
                    total: users.length,
                    onChange: (page, pageSize) => {
                        setPage(page);
                        setPageSize(pageSize)
                    }
                }}
            />
            <Modal
                title="Edit Employee"
                visible={isEditing}
                okText="Save"
                onCancel={() => {
                    resetEditing();
                }}
                onOk={() => {
                    setUsers((pre: any) => {
                        return pre.map((user: User) => {
                            if (user.id === (editingEmployee && editingEmployee.id)) {
                                return editingEmployee;
                            } else {
                                return user;
                            }
                        });
                    });
                    resetEditing();
                }}
            >
                <Input
                    value={editingEmployee?.userId}
                    onChange={(e) => {
                        setEditingEmployee((pre: any) => {
                            return { ...pre, userId: e.target.value };
                        });
                    }}
                />
                <Input
                    value={editingEmployee?.title}
                    onChange={(e) => {
                        setEditingEmployee((pre: any) => {
                            return { ...pre, title: e.target.value };
                        });
                    }}
                />
            </Modal>
        </div>
    );
}

export default TableWork;
