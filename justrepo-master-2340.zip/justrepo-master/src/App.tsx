import React from 'react';
import logo from './logo.svg';
import './App.css';
import TableWork from './tableComponent/TableWork';
import ChartWork from './tableComponent/ChartWork';
import { ButtonComponent } from './ButtonComponent';

function App() {
  return (
    <div className="App">
      <h1>Employee Details</h1>
      <TableWork />
    </div>
  );
}

export default App;
